package example;

public class Test {
    public void test() {
        System.out.println("Hello!");
    }
}