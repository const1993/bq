package example;

import java.util.Map;

public class ExampleModule extends ConfigModule {



}
