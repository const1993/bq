package example;

import io.bootique.BQTestFactory;

public class MyTest {

    @Rule
    public BQTestFactory testFactory = new BQTestFactory();
} 
